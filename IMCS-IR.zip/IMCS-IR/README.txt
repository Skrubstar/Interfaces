数据集下载文件为：IMCS-IR.zip, 包括：
● IMCS_train.json:  训练集，IMCS 3个子任务共享
● IMCS_dev.json:  验证集，IMCS 3个子任务共享
● IMCS_test.json:  测试集， IMCS 3个子任务共享
● symptom_norm.csv：共包含329个归一化后的症状实体。
● split.csv：数据集划分文件，数据集应划分好train/dev/test，选手无需关注
● IMCS-IR_test.json:  IMCS-IR任务的提交文件，提交格式请参照example_pred.json。
● example_gold.json: 标准答案示例
● example_pred.json: 提交结果示例
● README.txt: 说明文件

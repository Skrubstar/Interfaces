
Mainfest:
● CHIP-MDCFNPC_train.jsonl: 训练集 
● CHIP-MDCFNPC_dev.jsonl: 验证集
● CHIP-MDCFNPC_test.jsonl: 测试集, 选手提交的时候需要预测每个临床发现的attr字段
● example_gold.jsonl: 标准答案示例
● example_pred.jsonl: 提交结果示例
● README.txt: 说明文件

